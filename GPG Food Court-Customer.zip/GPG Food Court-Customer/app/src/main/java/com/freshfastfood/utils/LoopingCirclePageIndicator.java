package com.freshfastfood.utils;

public class LoopingCirclePageIndicator {
}
